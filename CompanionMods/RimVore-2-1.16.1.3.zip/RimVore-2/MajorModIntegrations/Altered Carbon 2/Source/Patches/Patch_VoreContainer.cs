﻿using AlteredCarbon;
using HarmonyLib;
using RimVore2;
using RimWorld;
using System;
using Verse;

namespace RV2_AC2
{
    [HarmonyPatch(typeof(VoreContainer), "DigestAllImplants")]
    internal static class Patch_VoreContainer
    {
        [HarmonyPrefix]
        public static void CreateStackThingForDigestedPawn(Pawn pawn, DamageDef damageDef, VoreContainer __instance)
        {
            try
            {
                // Code more or less stolen from AlteredCarbon.Hediff_NeuralStack.SpawnStack()
                if(!pawn.HasNeuralStack(out Hediff_NeuralStack hediff_NeuralStack))
                {
                    return;
                }

                RV2Log.Message($"Detected pawn with stack implant hediff, attempting to create stack thing", "AlteredCarbon");
                ThingDef sourceStack = hediff_NeuralStack.SourceStack;
                NeuralStack neuralStack = ThingMaker.MakeThing(sourceStack) as NeuralStack;
                if(hediff_NeuralStack.savedStyle != null)
                {
                    neuralStack.SetStyleDef(hediff_NeuralStack.savedStyle);
                }
                neuralStack.NeuralData.CopyFromPawn(pawn, sourceStack);
                neuralStack.NeuralData.CopyOriginalData(hediff_NeuralStack.NeuralData);

                Hediff_StackDegradation degradationHediff = pawn.health.hediffSet.GetFirstHediff<Hediff_StackDegradation>();
                if(degradationHediff != null)
                {
                    neuralStack.NeuralData.stackDegradation = degradationHediff.stackDegradation;
                    pawn.health.RemoveHediff(degradationHediff);
                    RV2Log.Message($"Detected stack deterioration of {degradationHediff.stackDegradation}", "AlteredCarbon");
                }

                pawn.health.RemoveHediff(hediff_NeuralStack);
                AlteredCarbonManager.Instance.RegisterStack(neuralStack);
                AlteredCarbonManager.Instance.RegisterExtractedStack(pawn, neuralStack);
                AlteredCarbonManager.Instance.ReplacePawnWithStack(pawn, neuralStack);
                AlteredCarbonManager.Instance.deadPawns.Add(pawn);
                neuralStack.NeuralData.hostPawn = null;
                if(!neuralStack.IsArchotechStack)
                {
                    float implantDamage = 0.5f * neuralStack.HitPoints;
                    DamageInfo dinfo = new DamageInfo(damageDef, implantDamage, float.MaxValue, -1);
                    neuralStack.TakeDamage(dinfo);
                }
                __instance.TryAddOrTransfer(neuralStack);
                RV2Log.Message($"Successfully created stack thing {neuralStack} and added to vore products", "AlteredCarbon");
            }
            catch(Exception e)
            {
                Log.Error("Error spawning digested stack: " + e);
            }
        }
    }
}