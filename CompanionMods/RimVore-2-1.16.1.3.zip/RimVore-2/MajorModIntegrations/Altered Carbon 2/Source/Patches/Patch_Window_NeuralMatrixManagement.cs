﻿using AlteredCarbon;
using HarmonyLib;
using RimVore2;
using System;
using System.Collections.Generic;
using System.Linq;
using Verse;

namespace RV2_AC2
{
    [HarmonyPatch(typeof(AlteredCarbon.Window_NeuralMatrixManagement), "RefreshItems")]
    internal static class Patch_Window_NeuralMatrixManagement
    {
        [HarmonyPostfix]
        public static void AddStacksFromVoredPawns(List<IStackHolder> ___allItems, Window_NeuralMatrixManagement __instance)
        {
            try
            {
                IEnumerable<IStackHolder> voredPawnStacks = GlobalVoreTrackerUtility.ActivePreyWithRecord.Keys
                    .Select(p => p.GetNeuralStack())
                    .Where(s => s != null && s.NeuralData.trackedToMatrix == __instance.matrix);
                ___allItems.AddRange(voredPawnStacks);
            }
            catch(Exception e)
            {
                Log.Error($"Error getting tracked vored stacks: {e}");
            }
        }
    }
}