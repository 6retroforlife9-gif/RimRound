﻿using System.Reflection;
using HarmonyLib;
using Verse;

namespace RV2_AC2
{
    [StaticConstructorOnStartup]
    public static class Startup
    {
        static Startup()
        {
            Harmony.DEBUG = false;
            Harmony harmony = new Harmony("rv2_ac2");
            harmony.PatchAll(Assembly.GetExecutingAssembly());
        }
    }
}
