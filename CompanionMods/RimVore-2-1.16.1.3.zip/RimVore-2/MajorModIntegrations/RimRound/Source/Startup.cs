using System;
using System.Linq;
using System.Reflection;
using RimVore2;
using RimWorld;
using Verse;

namespace RV2_RimRound
{
    [StaticConstructorOnStartup]
    public static class Startup
    {
        static Startup()
        {
            var type = AppDomain.CurrentDomain.GetAssemblies()
                .FirstOrDefault(assembly => assembly.GetName().Name == "RimRound")
                ?.GetType("RimRound.Utilities.ExternalNutrition", false);
            if (type == null)
            {
                Log.Message("[RimVore-2] No external nutrition API. Using native RimVore food handling.");
                return;
            }

            try
            {
                var version = type.GetField("ApiVersion", BindingFlags.Public | BindingFlags.Static);
                if (version == null || !Equals(version.GetRawConstantValue(), 1))
                    throw new NotSupportedException("Unsupported RimRound external nutrition API version");
                var eligible = Bind<Func<Pawn, bool>>(type, "IsEligible", typeof(Pawn));
                var capacity = Bind<Func<Pawn, float>>(type, "SoftCapacity", typeof(Pawn));
                var credit = Bind<Func<Pawn, float, bool>>(type, "TryCreditDigestion", typeof(Pawn), typeof(float));
                var expense = Bind<Action<Pawn, float>>(type, "RecordFoodExpense", typeof(Pawn), typeof(float));
                var register = Bind<Action<Func<Pawn, float>>>(type, "SetPassengerVolumeProvider", typeof(Func<Pawn, float>));
                // Replace intrinsic pawn mass before vanilla adds equipment and implants.
                // The separately loaded RV2 stat part adds contained cargo after both.
                var parts = StatDefOf.Mass.parts;
                var body = parts.FirstOrDefault(part => part.GetType().FullName == "RimRound.AI.StatPart_MassAdjustedByWeight");
                var gear = parts.FirstOrDefault(part => part.GetType().Name == "StatPart_GearAndInventoryMass");
                if (body != null && gear != null && parts.IndexOf(body) > parts.IndexOf(gear))
                {
                    parts.Remove(body);
                    parts.Insert(parts.IndexOf(gear), body);
                }
                register(RimRoundBridge.OccupiedVolume);
                RimRoundBridge.EligibleCarrier = eligible;
                RimRoundBridge.ComfortableCapacity = capacity;
                RimRoundBridge.TryCreditDigested = credit;
                RimRoundBridge.RecordFoodExpense = expense;
                Log.Message("[RimVore-2] RimRound passenger occupancy and digestion integration active.");
            }
            catch (Exception error)
            {
                Log.Warning("[RimVore-2] RimRound external nutrition API unavailable. Using native RimVore food handling. " + error);
            }
        }

        private static T Bind<T>(Type type, string name, params Type[] parameters) where T : class
        {
            var method = type.GetMethod(name, BindingFlags.Public | BindingFlags.Static, null, parameters, null);
            if (method == null) throw new MissingMethodException(type.FullName, name);
            return (T)(object)Delegate.CreateDelegate(typeof(T), method);
        }
    }
}

