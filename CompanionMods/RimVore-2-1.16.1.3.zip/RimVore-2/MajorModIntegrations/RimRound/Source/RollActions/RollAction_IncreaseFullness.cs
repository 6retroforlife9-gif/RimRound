using RimVore2;
using RimWorld;

namespace RV2_RimRound
{
    // Older stage workers can scribe this action under its original name.
    public class RollAction_IncreaseFullness : RollAction
    {
        public override bool TryAction(VoreTrackerRecord record, float rollStrength)
        {
            if (!base.TryAction(record, rollStrength)) return false;
            if (RimRoundBridge.HandlesFoodRoll(record)) return true;
            return RV2PawnUtility.TryIncreaseNeed(TargetPawn, NeedDefOf.Food, rollStrength);
        }
    }
}
