﻿using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Verse;

/// <summary>
/// Keeps track of all pawns containing other pawns inside of any of their bodyparts.
/// Pawn.Tick() is patched to check if a pawn is being tracked, if it is, it passes the tick down to all contained prey pawns
/// </summary>

namespace RimVore2
{
    public class VoreTracker : IExposable
    {
        public Pawn pawn;
        public List<VoreTrackerRecord> VoreTrackerRecords;
        public bool IsSynchronized = false;    // not scribed, so every time the game starts up again, it will force the vore tracker to synchronize the hediffs
        public string debug_pawnName;

        public bool IsTrackingVore => VoreTrackerRecords?.Count > 0;

        public bool HasPreyReadyToRelease => VoreTrackerRecords.Any(record => record.HasReachedEnd);
        public int PreyStrugglingCount => VoreTrackerRecords.Count(record => record.StruggleManager.ShouldStruggle);

        public VoreTracker() { }

        public VoreTracker(Pawn pawn)
        {
            this.pawn = pawn;
            debug_pawnName = pawn.GetDebugName();
            VoreTrackerRecords = new List<VoreTrackerRecord>();
        }

        public int DescendentCount()
        {
            int count = 0;
            foreach(VoreTrackerRecord record in VoreTrackerRecords)
            {
                // add prey
                count++;

                // add prey of prey
                VoreTracker preyTracker = record.Prey.PawnData()?.VoreTracker;
                if(preyTracker == null)
                {
                    continue;
                }
                count += preyTracker.DescendentCount();
            }
            return count;
        }

        public void TrackVore(VoreTrackerRecord record)
        {
            TryTrackVore(record); // Keep the signature used by existing optional integrations.
        }

        internal bool TryTrackVore(VoreTrackerRecord record)
        {
            if (record?.Prey == null || record.Predator != pawn || record.VoreContainer == null ||
                record.Prey.Dead || record.Prey.Destroyed) return false;
            var source = record.AdmissionSource;
            if (VoreTrackerRecords.Any(r => r.Prey == record.Prey && r != source && !r.ReleasePending))
                return false;
            if (!record.VoreContainer.HoldsPawn(record.Prey) &&
                !record.VoreContainer.TryAddOrTransferPrey(record.Prey)) return false;
            RimRoundBridge.Admit(record, source, false);
            if (source != null && !source.ReleasePending && source.IsTracked)
                source.VoreTracker.RemoveRegistered(source);
            record.VoreContainer.Retarget(pawn, record.VorePath.def);
            VoreTrackerRecords.Add(record);
            GlobalVoreTrackerUtility.Notify_RecordAdded(record);
            record.AdmissionSource = null;
            PreVoreUtility.CommitAdmission(record);
            record.Initialize();
            return record.IsTracked;
        }

        public VoreTrackerRecord SplitOffNewVore(VoreTrackerRecord originalRecord, Pawn newPrey, VorePath newPath = null, int forcedPathIndex = -1, bool isPathSwitch = false)
        {
            if(newPath == null)
            {
                newPath = new VorePath(originalRecord.VorePath.def);
            }
            VoreTrackerRecord newRecord = new VoreTrackerRecord(originalRecord)
            {
                Prey = newPrey,
                VorePath = newPath,
                Initiator = originalRecord.Initiator
            };
            newRecord.IsResultOfSwitchedPath = isPathSwitch;
            if(forcedPathIndex >= 0)
            {
                newRecord.VorePathIndex = forcedPathIndex;
            }

            if (newRecord.VorePathIndex < 0 || newRecord.VorePathIndex >= newRecord.VorePathCount) return null;
            PreVoreUtility.PopulateRecord(ref newRecord, true);
            if (!TryTrackVore(newRecord)) return null;
            if (RV2Log.ShouldLog(false, "VoreContainer"))
                RV2Log.Message($"Split off new record for {newPrey}: \nNEW: {newRecord}\nORIGINAL: {originalRecord}", "VoreContainer");
            return newRecord;
        }

        public void UntrackVore(VoreTrackerRecord record)
        {
            // A stock optional integration untracks its donor before registering the replacement.
            if (record.VoreContainer?.HoldsPawn(record.Prey) == true && !record.Prey.Dead) return;
            RemoveRegistered(record);
        }

        internal void RemoveRegistered(VoreTrackerRecord record)
        {
            if (!VoreTrackerRecords.Remove(record)) return;
            GlobalVoreTrackerUtility.Notify_RecordRemoved(record);
            RemoveVoredHediff();
            SynchronizeHediffs();
            if(RV2Log.ShouldLog(false, "Debug"))
                RV2Log.Message($"record {record.LogLabel} took {record.VorePath.path.Sum(stage => stage.PassedRareTicks)} rare ticks", "Debug");

            void RemoveVoredHediff()
            {
                if (record.Prey.GetVoreRecord() != null) return;
                Hediff voredHediff = record.Prey?.health?.hediffSet?.GetFirstHediffOfDef(RV2_Common.VoredHediff);
                if(voredHediff != null)
                {
                    record.Prey.health.RemoveHediff(voredHediff);
                }
            }
        }

        public IEnumerable<VoreTrackerRecord> AllRecordsIncludingNested()
        {
            foreach (VoreTrackerRecord record in VoreTrackerRecords)
            {
                yield return record;
                VoreTracker predatorTracker = record.Prey?.PawnData()?.VoreTracker;
                if (predatorTracker != null)
                {
                    foreach (VoreTrackerRecord innerRecord in predatorTracker.AllRecordsIncludingNested())
                    {
                        yield return innerRecord;
                    }
                }
            }
        }

        public void Tick()
        {
            if(!IsSynchronized)
            {
                SynchronizeHediffs();
            }
            if(!IsTrackingVore)
            {
                return;
            }
            if(pawn.Dead)
            {
                EmergencyEjectAll();
                return;
            }
            foreach(VoreTrackerRecord record in VoreTrackerRecords.ToList())
            {
                try
                {
                    if (record.IsTracked) record.Tick();
                }
                catch(Exception e)
                {
                    Log.Error("Exception during predator tick for record " + record.ToString() + "\n error: " + e);
                }
            }
        }

        public void TickRare()
        {
            if(!IsTrackingVore)
            {
                return;
            }
            if(pawn.Dead)
            {
                EmergencyEjectAll();
                return;
            }
            foreach(VoreTrackerRecord record in VoreTrackerRecords.ToList())
            {
                try
                {
                    if (record.IsTracked) record.TickRare();
                }
                catch(Exception e)
                {
                    Log.Error("Exception during predator rare tick for record " + record.ToString() + "\n error: " + e);
                }
            }
        }

        public void SynchronizeHediffs()
        {
            if(pawn.health?.hediffSet == null)
            {
                if(RV2Log.ShouldLog(false, "VoreHediffs"))
                    RV2Log.Message($"Pawn {pawn.LabelShort} has no health, no vore hediffs to apply", "VoreHediffs");
                return;
            }
            if(RV2Log.ShouldLog(true, "VoreHediffs"))
                RV2Log.Message($"Synchronizing hediffs for {pawn.LabelShort}", false, "VoreHediffs");
            ResetHediffConnections();
            foreach(VoreTrackerRecord record in VoreTrackerRecords)
            {
                if (record.ReleasePending && !record.VoreContainer.HoldsPawn(record.Prey)) continue;
                ConnectHediff(record);
                EnsurePreyHediff(record.Prey);
            }
            UpdateHediffs();
            IsSynchronized = true;
        }

        private void EnsurePreyHediff(Pawn pawn)
        {
            if(!pawn.health.hediffSet.HasHediff(RV2_Common.VoredHediff))
            {
                pawn.health.AddHediff(RV2_Common.VoredHediff);
            }
        }

        private void ResetHediffConnections()
        {
            IEnumerable<Hediff_ContainingPrey> voreHediffs = pawn.health.hediffSet.hediffs
                .FindAll(hediff => hediff is Hediff_ContainingPrey)
                .Cast<Hediff_ContainingPrey>();
            voreHediffs.ForEach(hediff =>
            {
                if(RV2Log.ShouldLog(true, "VoreHediffs"))
                    RV2Log.Message($"Clearing connected records for hediff {hediff.Label}", false, "VoreHediffs");
                hediff.ConnectedVoreRecords.Clear();
            });
        }

        private void ConnectHediff(VoreTrackerRecord record)
        {
            HediffDef hediffDef = record.CurrentHediffDef;
            Hediff hediff = pawn.health.hediffSet.GetFirstHediffOfDef(hediffDef);
            if(hediff == null)
            {
                hediff = pawn.health.AddHediff(hediffDef, record.CurrentBodyPart);
            }
            Hediff_ContainingPrey voreHediff = (Hediff_ContainingPrey)hediff;
            voreHediff.ConnectedVoreRecords.Add(record);
            if(RV2Log.ShouldLog(true, "VoreHediffs"))
                RV2Log.Message($"Connected {record.LogLabel} to hediff {voreHediff.Label}", false, "VoreHediffs");
        }

        private void UpdateHediffs()
        {
            IEnumerable<Hediff_ContainingPrey> voreHediffs = pawn.health.hediffSet.hediffs
                .FindAll(hediff => hediff is Hediff_ContainingPrey)
                .Cast<Hediff_ContainingPrey>();
            foreach(Hediff_ContainingPrey voreHediff in voreHediffs)
            {
                if(voreHediff.ConnectedVoreRecords.Count == 0)
                {
                    if(RV2Log.ShouldLog(true, "VoreHediffs"))
                        RV2Log.Message($"Removing vore hediff without VoreTrackerConnections: {pawn.LabelShort} | {voreHediff.Label}", false, "VoreHediffs");
                    pawn.health.RemoveHediff(voreHediff);
                }
                else
                {
                    voreHediff.UpdateLabel();
                }
            }
        }

        public void EmergencyEjectAll()
        {
            foreach(VoreTrackerRecord record in VoreTrackerRecords?.ToList())
            {
                try
                {
                    EmergencyEject(record);
                }
                catch (Exception e)
                {
                    Log.Error($"Unhandled exception caught: {e}");
                }
            }
        }

        public void EmergencyEject(VoreTrackerRecord record)
        {
            if (record == null || !record.IsTracked) return;
            record.EmergencyReleasePending = true;
            TryRelease(record);
        }

        public void EjectAll(bool ignoreCanEjectRestrictions = false)
        {
            foreach(VoreTrackerRecord record in VoreTrackerRecords?.ToList())
            {
                Eject(record, ignoreCanEjectRestrictions: ignoreCanEjectRestrictions);
            }
        }

        public void Eject(VoreTrackerRecord record, Pawn ejectingPawn = null, bool ignoreCanEjectRestrictions = false, bool simulateNullMap = false)
        {
            if (record == null || !record.IsTracked || (!ignoreCanEjectRestrictions && !record.CanEject)) return;
            record.ReleaseInitiator = ejectingPawn;
            record.NullMapReleasePending |= simulateNullMap;
            TryRelease(record);
        }

        internal void TryRelease(VoreTrackerRecord record)
        {
            int now = Find.TickManager.TicksGame;
            if (record.ReleasePending && now < record.NextReleaseRetry) return;
            record.ReleasePending = true;
            record.NextReleaseRetry = now + 60;
            try
            {
                record.VoreContainer.TryDropAllThings(record.NullMapReleasePending);
            }
            catch (Exception error)
            {
                RV2Log.Warning($"Could not finish dropping {record.LogLabel}: {error}", "VoreContainer");
            }
            // A failed/partial release retains only its remaining contents. A subsequent rare
            // tick retries the physical move without repeating the stages or their payouts.
            if (record.Prey != null && !record.Prey.Dead && !record.VoreContainer.HoldsPawn(record.Prey) &&
                record.Prey.GetVoreRecord() == record)
            {
                GlobalVoreTrackerUtility.ActivePreyWithRecord.Remove(record.Prey);
                var hediff = record.Prey.health?.hediffSet?.GetFirstHediffOfDef(RV2_Common.VoredHediff);
                if (hediff != null) record.Prey.health.RemoveHediff(hediff);
            }
            if (record.VoreContainer.GetDirectlyHeldThings().Count != 0) return;
            RemoveRegistered(record);
            if (record.EmergencyReleasePending)
            {
                if (record.OffMapReleasePending) record.FinishOffMapRelease();
                return;
            }
            PostVoreUtility.ResolveVore(record);
            if (record.ReleaseInitiator != null && record.IsInterrupted)
                PostVoreUtility.RegisterInterruptedVoreEvent(record.ReleaseInitiator);
        }

        public void ExposeData()
        {
            Scribe_Collections.Look(ref VoreTrackerRecords, "TrackedVores", LookMode.Deep, new object[0]);
            Scribe_References.Look(ref pawn, "pawn", true);
            Scribe_Values.Look(ref debug_pawnName, "debug_pawnName");
            if(Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                foreach(VoreTrackerRecord record in VoreTrackerRecords.ToList())
                {
                    if(record.Predator == null)
                    {
                        Log.Error("Had to remove vore record due to missing Predator");
                        VoreTrackerRecords.Remove(record);
                        continue;
                    }
                    if(record.Prey == null)
                    {
                        Log.Error("Had to remove vore record due to missing Prey");
                        VoreTrackerRecords.Remove(record);
                        continue;
                    }
                }
                if(debug_pawnName == null)
                {
                    debug_pawnName = pawn.GetDebugName();
                }
            }
        }

        public override string ToString()
        {
            if(VoreTrackerRecords.Count == 0)
            {
                return "<EmptyVoreTracker>";
            }
            return string.Join("\n", VoreTrackerRecords.ConvertAll(v => v.ToString()));
        }
    }
}
