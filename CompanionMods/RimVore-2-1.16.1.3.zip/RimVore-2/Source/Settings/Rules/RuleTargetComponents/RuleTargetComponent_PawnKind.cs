﻿using System;
using System.Linq;
using Verse;

namespace RimVore2
{
    public class RuleTargetComponent_PawnKind : RuleTargetComponent
    {
        public override string ButtonTranslationKey => "RV2_Settings_Rule_RuleTargetComponent_PawnKind";
        string targetPawnKindDefName;
        public RuleTargetComponent_PawnKind() : base() { }
        public RuleTargetComponent_PawnKind(RuleTargetRole targetRole, string targetPawnKindDefName) : base(targetRole)
        {
            this.targetPawnKindDefName = targetPawnKindDefName;
        }


        public override string Label => $"{ButtonTranslationKey.Translate()}: {TargetPawnKind.label}";
        PawnKindDef TargetPawnKind => targetPawnKindDefName == null ? null : PawnKindDef.Named(targetPawnKindDefName);

        protected override bool AppliesToPawnInteral(Pawn pawn)
        {
            return pawn.kindDef == TargetPawnKind;
        }
        public override string PawnExplanation(Pawn pawn)
        {
            return "RV2_Settings_Rule_RuleExplanation_PawnKind".Translate(pawn.LabelShortCap, pawn.def.defName);
        }
        public override object Clone()
        {
            return new RuleTargetComponent_PawnKind()
            {
                TargetRole = TargetRole,
                inverted = inverted,
                targetPawnKindDefName = targetPawnKindDefName
            };
        }

        readonly Func<PawnKindDef, string> pawnKindLabelGetter = (PawnKindDef pawnKind) => pawnKind.LabelCap;
        readonly Func<PawnKindDef, string> pawnKindTooltipGetter = (PawnKindDef pawnKind) => pawnKind.description;
        public override void DrawInteractibleInternal(Listing_Standard list)
        {
            Action<PawnKindDef> pawnKindSelection = (PawnKindDef newPawnKind) => targetPawnKindDefName = newPawnKind.defName;
            list.CreateLabelledDropDown(RV2_Common.AllPawnKinds, TargetPawnKind, pawnKindLabelGetter, pawnKindSelection, null, "RV2_Settings_Rule_RuleTargetComponent_PawnKind".Translate(), null, pawnKindTooltipGetter);
        }

        public override RuleTargetStaleTrigger MakeStaleTrigger()
        {
            return new RuleTargetStaleTrigger_Never();
        }

        public override bool IsValid()
        {
            return RV2_Common.AllPawnKinds.Any(def => def.defName == targetPawnKindDefName);
        }
        public override void SetFallback(out string message)
        {
            string originalDefName = targetPawnKindDefName;
            targetPawnKindDefName = RV2_Common.AllPawnKinds.First().defName;
            message = $"{this.GetType()} is no longer valid due to unloaded Def {originalDefName}. Resetting to {targetPawnKindDefName}";
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref targetPawnKindDefName, "targetPawnKindDefName");
        }
    }
}
