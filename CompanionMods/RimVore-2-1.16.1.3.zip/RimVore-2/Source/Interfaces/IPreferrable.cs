﻿using Verse;

namespace RimVore2
{
    interface IPreferrable
    {
        float GetPreference(Pawn pawn, VoreRole role, ModifierOperation modifierOperation = ModifierOperation.Add);
        string GetName();
    }
}
