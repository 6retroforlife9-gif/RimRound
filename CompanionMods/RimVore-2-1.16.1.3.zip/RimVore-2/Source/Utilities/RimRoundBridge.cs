using System;
using System.Linq;
using RimWorld;
using Verse;

namespace RimVore2
{
    // Installed by the optional adapter. The core has no RimRound assembly reference.
    public static class RimRoundBridge
    {
        public static Func<Pawn, bool> EligibleCarrier;
        public static Func<Pawn, float> ComfortableCapacity;
        public static Func<Pawn, float, bool> TryCreditDigested;
        public static Action<Pawn, float> RecordFoodExpense;

        internal static bool Eligible(Pawn carrier) => carrier != null && !carrier.Dead &&
            EligibleCarrier != null && ComfortableCapacity != null && TryCreditDigested != null &&
            EligibleCarrier(carrier);

        public static bool HandlesFoodRoll(VoreTrackerRecord record) =>
            record?.Passenger?.Bridged == true;

        public static float OccupiedVolume(Pawn carrier)
        {
            if (!Eligible(carrier)) return 0f;
            var component = Current.Game?.GetComponent<RV2Component>();
            if (component == null || !component.HasPawnData(carrier)) return 0f;
            var records = component.GetPawnData(carrier).VoreTracker?.VoreTrackerRecords;
            if (records == null) return 0f;
            double occupied = 0d;
            foreach (var record in records)
                if (record.Predator == carrier) occupied += PassengerVolume(record);
            return (float)Math.Min(float.MaxValue, occupied);
        }

        public static float PassengerVolume(VoreTrackerRecord record)
        {
            if (record?.Passenger?.Bridged != true || record.Prey == null || record.Prey.Dead ||
                record.Prey.Destroyed || record.VoreContainer?.HoldsPawn(record.Prey) != true) return 0f;
            return Positive(record.Passenger.Volume) ? record.Passenger.Volume : 0f;
        }

        internal static void Admit(VoreTrackerRecord record, VoreTrackerRecord source, bool imported)
        {
            var previous = source?.Prey == record.Prey ? source.Passenger : null;
            bool sameCarrier = previous != null && source.Predator == record.Predator;
            bool bridged = sameCarrier ? previous.Bridged : Eligible(record.Predator);
            bool nativePayment = record.VorePath.def.feedsPredator && (!bridged || imported);
            var preyData = record.Prey.PawnData();
            if (nativePayment) preyData.RimRoundNutritionClaimed = true;
            var account = new PassengerAccount
            {
                Lineage = previous?.Lineage ?? record.loadID,
                Bridged = bridged,
                Volume = sameCarrier ? previous.Volume : OccupancyOnAdmission(record, bridged),
                HasSourceBudget = previous?.HasSourceBudget == true || (bridged && !imported && !nativePayment),
                SourceNutrition = previous?.HasSourceBudget == true ? previous.SourceNutrition :
                    (bridged && !imported && !preyData.RimRoundNutritionClaimed ? SourceNutrition(record) : 0f),
                Settled = previous?.Settled == true || preyData.RimRoundNutritionClaimed || nativePayment,
                Credited = previous?.Credited ?? 0f
            };
            record.Passenger = account;
        }

        private static float SourceNutrition(VoreTrackerRecord record)
        {
            Pawn prey = record.Prey;
            if (prey.Dead || prey.Destroyed || prey.RaceProps?.IsFlesh != true ||
                prey.RaceProps.meatDef == null || prey.RaceProps.meatDef.GetStatValueAbstract(StatDefOf.Nutrition) <= 0f)
                return 0f;
            try
            {
                if (FoodUtility.GetFinalIngestibleDef(prey) == null && !Positive(prey.GetStatValue(StatDefOf.MeatAmount))) return 0f;
                float value = VoreCalculationUtility.CalculatePreyNutrition(prey, record.Predator);
                return Positive(value) ? value : 0f;
            }
            catch (Exception error)
            {
                Log.Warning($"RV2 RimRound could not establish edible nutrition for {prey}: {error}");
                return 0f;
            }
        }

        private static bool Positive(float value) =>
            value > 0f && !float.IsNaN(value) && !float.IsInfinity(value);

        private static float OccupancyOnAdmission(VoreTrackerRecord record, bool bridged)
        {
            if (!bridged || record.Prey.Dead || !record.VoreContainer.HoldsPawn(record.Prey)) return 0f;
            float size = record.Prey.BodySize;
            float capacity = record.Predator.CalculateVoreCapacity();
            if (!Positive(capacity) || capacity >= RV2_Common.VoreStorageCapacityToBeConsideredInfinite)
                capacity = record.Predator.BodySize;
            float soft = ComfortableCapacity(record.Predator);
            if (!Positive(soft) || !Positive(size) || !Positive(capacity)) return 0f;
            return soft * .5f * Math.Min(1f, size / capacity);
        }

        internal static void FinishDigest(VoreTrackerRecord record, bool consumed)
        {
            PassengerAccount account = record.Passenger;
            if (account == null || !account.Bridged || account.Settled) return;
            account.Settled = true;
            var preyData = record.Prey.PawnData();
            bool alreadyClaimed = preyData.RimRoundNutritionClaimed;
            preyData.RimRoundNutritionClaimed = true;
            if (!consumed || alreadyClaimed || !Positive(account.SourceNutrition) || !KnownFeedingOutputs(record)) return;
            account.Pending = account.SourceNutrition;
            RetryCredit(record);
        }

        // Whitelist the two stock feeding paths. If a definition can generate a later edible
        // output, reserve the entire source for it rather than estimating an unknown share.
        private static bool KnownFeedingOutputs(VoreTrackerRecord record)
        {
            var path = record.VorePath.def;
            if (!path.feedsPredator || (path.defName != "OralDigest" && path.defName != "AnalDigest") ||
                record.CurrentVoreStage?.def.defName != "Stomach_Digest") return false;
            var product = path.voreProduct;
            if (product == null || product.items?.Any(Edible) == true || product.containerItems?.Any(Edible) == true ||
                record.VoreContainer.ExistingProduct?.ProvideItems()?.Any(Edible) == true) return false;
            return !RollUtility.GetAllRollActions(path, stage => stage.onStart)
                .Concat(RollUtility.GetAllRollActions(path, stage => stage.onCycle))
                .Concat(RollUtility.GetAllRollActions(path, stage => stage.onEnd))
                .Any(action => action is RollAction_CreateThings && !(action is RollAction_CreateThingsFromContainer));
        }

        private static bool Edible(ThingDef def) => def == null || def.IsNutritionGivingIngestible;

        internal static void RetryCredit(VoreTrackerRecord record)
        {
            var account = record.Passenger;
            if (account == null || !Positive(account.Pending) || !Eligible(record.Predator)) return;
            float amount = account.Pending;
            account.Pending = 0f; // Prevent reentrant settlement. Exceptions have uncertain effects and must not replay.
            try
            {
                if (TryCreditDigested(record.Predator, amount)) account.Credited += amount;
                else account.Pending = amount; // A declined request changes neither ledger.
            }
            catch (Exception error)
            {
                Log.Error($"RV2 RimRound could not confirm digestion credit for source {account.Lineage}: {error}");
            }
        }

        internal static void FoodSpent(Pawn pawn, float actual)
        {
            if (Positive(actual) && Eligible(pawn)) RecordFoodExpense?.Invoke(pawn, actual);
        }
    }

    internal sealed class PassengerAccount : IExposable
    {
        public int Lineage;
        public bool Bridged;
        public float Volume;
        public bool HasSourceBudget;
        public float SourceNutrition;
        public bool Settled;
        public float Pending;
        public float Credited;

        public void ExposeData()
        {
            Scribe_Values.Look(ref Lineage, "sourceRecord");
            Scribe_Values.Look(ref Bridged, "bridged");
            Scribe_Values.Look(ref Volume, "occupiedVolume");
            Scribe_Values.Look(ref HasSourceBudget, "hasSourceBudget");
            Scribe_Values.Look(ref SourceNutrition, "sourceNutrition");
            Scribe_Values.Look(ref Settled, "settled");
            Scribe_Values.Look(ref Pending, "earnedPending");
            Scribe_Values.Look(ref Credited, "credited");
        }
    }
}
