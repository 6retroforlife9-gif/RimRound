﻿using System.Collections.Generic;
using Verse;

namespace RimVore2
{
    public static class ReservedProposalTargetCache
    {
        const int cacheTimeout = 60000;    // full in-game day
        static readonly Dictionary<Pawn, int> cachedPawns = new Dictionary<Pawn, int>();

        public static bool Contains(Pawn pawn)
        {
            // guard against null/destroyed pawns
            if(pawn == null || pawn.Destroyed)
            {
                return false;
            }

            // pawn not cached
            if(!cachedPawns.TryGetValue(pawn, out int cachedTick))
            {
                return false;
            }

            // pawn is cached, check caching tick timeout
            if(GenTicks.TicksGame - cachedTick > cacheTimeout)
            {
                if(RV2Log.ShouldLog(false, "Debug"))
                {
                    RV2Log.Message($"Pawn {pawn.LabelShort} was cached as proposal target, but timed out", "Debug");
                }

                cachedPawns.Remove(pawn);
                return false;
            }
            return true;
        }
        public static void Add(Pawn pawn)
        {
            cachedPawns.SetOrAdd(pawn, GenTicks.TicksGame);
        }
        public static void AddRange(IEnumerable<Pawn> pawns)
        {
            foreach(Pawn pawn in pawns)
            {
                Add(pawn);
            }
        }
        public static void Remove(Pawn pawn)
        {
            cachedPawns.Remove(pawn);
        }
    }
}
